G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,10.0.1*
G04 #@! TF.CreationDate,2026-05-06T22:38:15+02:00*
G04 #@! TF.ProjectId,pogoAdapter,706f676f-4164-4617-9074-65722e6b6963,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 10.0.1) date 2026-05-06 22:38:15*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10C,2.200000*%
%ADD11C,3.000000*%
%ADD12RoundRect,0.249999X-0.850001X-0.850001X0.850001X-0.850001X0.850001X0.850001X-0.850001X0.850001X0*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,J2*
X148959988Y-87786989D03*
G04 #@! TD*
G04 #@! TO.C,J4*
X143879988Y-87786989D03*
G04 #@! TD*
D11*
G04 #@! TO.C,H2*
X153701657Y-76995010D03*
G04 #@! TD*
G04 #@! TO.C,H4*
X154500000Y-91600000D03*
G04 #@! TD*
D10*
G04 #@! TO.C,J6*
X138799988Y-87786989D03*
G04 #@! TD*
G04 #@! TO.C,J3*
X146419988Y-87786989D03*
G04 #@! TD*
G04 #@! TO.C,J5*
X141339988Y-87786989D03*
G04 #@! TD*
G04 #@! TO.C,J1*
X151499988Y-87786989D03*
G04 #@! TD*
D11*
G04 #@! TO.C,H1*
X135800000Y-91500000D03*
G04 #@! TD*
G04 #@! TO.C,H3*
X136500000Y-77000000D03*
G04 #@! TD*
D12*
G04 #@! TO.C,J7*
X138880000Y-82750000D03*
D10*
X141420000Y-82750000D03*
X143960000Y-82750000D03*
X146500000Y-82750000D03*
X149040000Y-82750000D03*
X151580000Y-82750000D03*
G04 #@! TD*
M02*
